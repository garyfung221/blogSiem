<?php

$con = mysqli_connect('localhost','gary221','1234567q','logs_db');


if(!$con){
    
    die("FAILED to Connect Database !");
}
?>