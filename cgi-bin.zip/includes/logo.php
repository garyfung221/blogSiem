<div>
<img src="./images/logo_transparent2.png" alt="" width="360" height="350">
 </div>