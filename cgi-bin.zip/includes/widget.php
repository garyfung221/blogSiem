<div class="well">
 <h4>About Me</h4>
 <p>This website is for the personal sharing of information purpose, If you have any problems please contact with :</br><br>E-mail: garyfung266@gmail.com
<br>
<br>
Copyright © Gary Fung</p>
 </div>