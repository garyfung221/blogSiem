<?php

$connection = mysqli_connect('localhost','blog_siem_user','1234567q','blog_siem');

if(!$connection){
    
    die("FAILED to Connect Database !");
}

?>